<?php
    session_start();

    // Include database connection file
    include("../includes/connection.php");

    // Check if 'id' is set in the GET parameters
    if(isset($_GET['id'])) {
        // Sanitize the input 'id' to prevent SQL injection
        $id = intval($_GET['id']);

        // Construct the SQL delete query with a prepared statement
        $query = "DELETE FROM contact WHERE c_id = ?";
        $stmt = mysqli_prepare($link, $query);
        
        // Bind the parameter and execute the query
        mysqli_stmt_bind_param($stmt, "i", $id);
        $success = mysqli_stmt_execute($stmt);
        
        // Close the statement
        mysqli_stmt_close($stmt);
        
        // Check if the query was successful
        if ($success) {
            $_SESSION['success'] = "Contact deleted successfully";
        } else {
            $_SESSION['error'][] = "Failed to delete contact";
        }
    } else {
        $_SESSION['error'][] = "Contact ID not provided";
    }

    // Close the database connection
    mysqli_close($link);

    // Redirect to the contact view page
    header("location:contact_view.php");
    exit; // Exit script after redirection
?>
