<?php
    session_start();

    // Check if form data is submitted
    if (!empty($_POST)) {
        // Extract form data
        extract($_POST);
        
        // Initialize error array
        $_SESSION['error'] = array();
        
        // Check if category name is provided
        if (empty($cat)) {
            $_SESSION['error'][] = "Please enter Category Name";
            header("location:category_edit.php?id=$id");
            exit; // Exit script after redirection
        }
        
        // Include database connection file
        include("../includes/connection.php");

        // Update query using prepared statement
        $query = "UPDATE category SET cat_nm=? WHERE cat_id=?";
        $stmt = mysqli_prepare($link, $query);
        mysqli_stmt_bind_param($stmt, "si", $cat, $id);
        
        // Execute query
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success'] = "Category updated successfully";
        } else {
            $_SESSION['error'][] = "Failed to update category";
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
        
        // Close connection
        mysqli_close($link);
        
        // Redirect to category view page
        header("location:category_view.php");
        exit; // Exit script after redirection
    } else {
        // Redirect if form data is not submitted
        header("location:category_view.php");
        exit; // Exit script after redirection
    }
?>
