<?php
    // Start session
    session_start();

    // Include header
    include("includes/header.php");

    // Include connection
    include("../includes/connection.php");

    // Check if book ID is provided in the URL
    if(isset($_GET['id'])) {
        $book_id = $_GET['id'];

        // Fetch book details from the database
        $query = "SELECT * FROM book WHERE b_id = $book_id";
        $result = mysqli_query($link, $query);

        // Check if the book exists
        if(mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
        } else {
            echo "Book not found.";
            exit;
        }
    } else {
        echo "Book ID is missing.";
        exit;
    }
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Update Book</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Edit Book
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <form role="form" action="process_book_edit.php" method="post" enctype="multipart/form-data">

                                <input type="hidden" name="id" value="<?php echo $row['b_id']; ?>" />

                                <div class="form-group">
                                    <label>Book Name</label>
                                    <?php
                                        if(isset($_SESSION['error']['bnm']))
                                        {
                                            echo '<p class="error">'.$_SESSION['error']['bnm'].'</p>';
                                        } 
                                    ?>
                                    <input type="text" name="bnm" value="<?php echo $row['b_nm'] ?>" class="form-control">
                                </div>


                                <div class="form-group">
                                    <label>Book Category</label>
                                    <select name="cat" class="form-control">
                                        <?php
                                            // Fetch categories from the database
                                            $cq = "SELECT * FROM category";
                                            $cres = mysqli_query($link, $cq);
                                            while($crow = mysqli_fetch_assoc($cres)) {
                                                $selected = ($crow['cat_id'] == $row['b_cat']) ? "selected" : "";
                                                echo '<option value="'.$crow['cat_id'].'" '.$selected.'>'.$crow['cat_nm'].'</option>';
                                            }
                                        ?>
                                    </select>
                                </div>

                                
                                <div class="form-group">
                                    <label>Description
                                        <?php
                                            if(isset($_SESSION['error']['desc']))
                                            {
                                                echo '<p class="error">'.$_SESSION['error']['desc'].'</p>';
                                            }
                                        ?>
                                    </label>
                                    <textarea name="desc" rows="3" class="form-control">
                                        <?php echo $row['b_desc'] ?>
                                    </textarea>
                                </div>


                                <div class="form-group">
                                    <label>Price</label>
                                    <?php
                                        if(isset($_SESSION['error']['price']))
                                        {
                                            echo '<p class="error">'.$_SESSION['error']['price'].'</p>';
                                        } 
                                    ?>
                                    <input type="text" name="price" value="<?php echo $row['b_price'] ?>" class="form-control">
                                </div>


                                <div class="form-group">
                                    <label>Book Image</label>
                                    <?php
                                        if(isset($_SESSION['error']['b_img']))
                                        {
                                            echo '<p class="error">'.$_SESSION['error']['b_img'].'</p>';
                                        }
                                    ?>
                                    <input type="file" name="b_img" class="form-control">
                                </div>


                                <button type="submit" class="btn btn-default">Update Book</button>

                                <a href="book_view.php" class="btn btn-default">Exit</a>

                            </form>

                            <?php
                                unset($_SESSION['error']);
                            ?>

                        </div>
                        <!-- /.col-lg-6 (nested) -->
                    
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->

<?php
    // Include footer
    include("includes/footer.php");
?>
