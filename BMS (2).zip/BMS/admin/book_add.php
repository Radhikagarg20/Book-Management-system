<?php
    // Start session
    //session_start();

    // Include header
    include("includes/header.php");
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add Book</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Add New Book
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <form role="form" action="process_book_add.php" method="post" enctype="multipart/form-data">

                                <div class="form-group">
                                    <label>Book Name</label>
                                    <?php
                                        // Check if 'bnm' error is set
                                        if(isset($_SESSION['error']['bnm'])) {
                                            echo '<p class="error">'.$_SESSION['error']['bnm'].'</p>';
                                        }
                                    ?>
                                    <input type="text" name="bnm" class="form-control">
                                </div>

                                <div class="form-group">
                                    <label>Book Category</label>
                                    <select name="cat" class="form-control">
                                        <?php
                                            // Include connection
                                            include("../includes/connection.php");

                                            // Fetch categories
                                            $cq = "SELECT * FROM category";
                                            $cres = mysqli_query($link, $cq);
                                            while($crow = mysqli_fetch_assoc($cres)) {
                                                echo '<option value="'.$crow['cat_id'].'">'.$crow['cat_nm'].'</option>';
                                            }
                                        ?>
                                    </select>
                                </div>

                                <!-- Other form fields -->

                                <button type="submit" class="btn btn-default">Add Book</button>
                                <button type="reset" class="btn btn-default">Reset</button>
                            </form>

                            <?php
                                // Unset error session
                                unset($_SESSION['error']);
                            ?>
                        </div>
                        <!-- /.col-lg-12 (nested) -->
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->

<?php
    // Include footer
    include("includes/footer.php");
?>
