<?php

session_start();

if (!empty($_POST)) {
    $_SESSION['error'] = array();
    $cat = $_POST['cat'];

    if (empty($cat)) {
        $_SESSION['error']['cat'] = "Please Enter Category Name";
        header("location:category_add.php");
        exit;
    }

    include("../includes/connection.php");

    // Using prepared statement to prevent SQL injection
    $q = "INSERT INTO category(cat_nm) VALUES(?)";
    $stmt = mysqli_prepare($link, $q);
    mysqli_stmt_bind_param($stmt, "s", $cat);
    mysqli_stmt_execute($stmt);

    header("location:category_add.php");
    exit;
} else {
    header("location:category.php");
    exit;
}

?>
