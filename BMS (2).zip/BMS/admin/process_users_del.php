<?php
    session_start();

    // Include database connection file
    include("../includes/connection.php");

    // Check if 'id' is set in the GET parameters
    if(isset($_GET['id'])) {
        // Sanitize the input 'id' to prevent SQL injection
        $id = intval($_GET['id']);

        // Construct the SQL delete query
        $query = "DELETE FROM register WHERE r_id = ?";
        
        // Prepare the delete statement
        $stmt = mysqli_prepare($link, $query);

        // Bind the 'id' parameter
        mysqli_stmt_bind_param($stmt, "i", $id);

        // Execute the delete statement
        if(mysqli_stmt_execute($stmt)) {
            $_SESSION['success'] = "User deleted successfully";
        } else {
            $_SESSION['error'][] = "Failed to delete user";
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        $_SESSION['error'][] = "User ID not provided";
    }

    // Close the database connection
    mysqli_close($link);

    // Redirect to the users view page
    header("location:users_view.php");
    exit; // Exit script after redirection
?>
