<?php
    session_start();
    include("../includes/connection.php");

    // Check if category id is provided in the URL
    if (isset($_GET['id']) && is_numeric($_GET['id'])) {
        // Prepare and execute the deletion query
        $id = $_GET['id'];
        $query = "DELETE FROM category WHERE cat_id = ?";
        $stmt = mysqli_prepare($link, $query);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);

        // Check if deletion was successful
        if (mysqli_affected_rows($link) > 0) {
            $_SESSION['success'] = "Category deleted successfully";
        } else {
            $_SESSION['error'] = "Failed to delete category";
        }
    } else {
        $_SESSION['error'] = "Invalid category id";
    }

    // Redirect to category view page
    header("location: category_view.php");
    exit;
?>
